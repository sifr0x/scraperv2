package usecase

import (
	"log"
	"net"
	"net/http"
	"runtime"
	"sync"
	"time"

	"github.com/datahuys/scraperv2/domain"
	"golang.org/x/net/proxy"
)

type scraperUsecase struct {
	scraperRepo domain.ScraperRepository
	proxyRepo   domain.ProxyRepository
	agentRepo   domain.UserAgentRepository
	wozDiskRepo domain.WozDestinationRepository
	wozFunc     func(*http.Client, string) (domain.WozRepository, error)

	wg  *sync.WaitGroup
	sem Semaphore
}

func NewScraperUsecase(scraperRepo domain.ScraperRepository, proxyRepo domain.ProxyRepository, agentRepo domain.UserAgentRepository, wozDiskRepo domain.WozDestinationRepository, wozFunc func(*http.Client, string) (domain.WozRepository, error)) domain.ScraperUsecase {
	wg := new(sync.WaitGroup)
	sem := New(12)

	return &scraperUsecase{
		scraperRepo,
		proxyRepo,
		agentRepo,
		wozDiskRepo,
		wozFunc,
		wg,
		sem,
	}
}

func (u *scraperUsecase) worker() {
	defer u.sem.Release()
	defer u.wg.Done()

	err := u.newSession()
	if err != nil {
		log.Println(err)
	}
}

func (u *scraperUsecase) Start() {
	i := 0
	for i < 11000000 {
		u.sem.Acquire()
		u.wg.Add(1)
		go u.worker()
		i++
	}

	u.wg.Wait()
}

func (u *scraperUsecase) newSession() (err error) {
	scrapedItems := 0

	agent, err := u.agentRepo.GetRandomUserAgent()
	if err != nil {
		return
	}

	proxyStr, err := u.proxyRepo.GetRandomUserProxy()
	if err != nil {
		return
	}

	baseDialer := &net.Dialer{
		Timeout:   30 * time.Second,
		KeepAlive: 30 * time.Second,
	}

	dialSocksProxy, err := proxy.SOCKS5("tcp", proxyStr, nil, baseDialer)
	if err != nil {
		return
	}

	httpClient := &http.Client{
		Transport: &http.Transport{
			Dial:                  dialSocksProxy.Dial,
			MaxIdleConns:          10,
			IdleConnTimeout:       60 * time.Second,
			TLSHandshakeTimeout:   10 * time.Second,
			ExpectContinueTimeout: 1 * time.Second,
			MaxIdleConnsPerHost:   runtime.GOMAXPROCS(0) + 1,
		},
	}

	session, err := u.wozFunc(httpClient, agent)
	if err != nil {
		return
	}

	for scrapedItems != 10 {
		id, err := u.scraperRepo.GetID()
		if err != nil {
			return err
		}

		woz, err := session.GetByID(id)
		if err != nil {
			return err
		}

		err = u.wozDiskRepo.Store(woz)
		if err != nil {
			return err
		}
		scrapedItems++
	}
	log.Printf("scraped %d items with %s/%s\n", scrapedItems, proxyStr, agent)
	return
}
